package com.tibco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TibcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
