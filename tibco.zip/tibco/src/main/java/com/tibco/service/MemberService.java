package com.tibco.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tibco.dao.LoyalitySegmentRepository;
import com.tibco.dao.MemberRepository;
import com.tibco.model.LoyalitySegment;
import com.tibco.model.Members;

@Service
public class MemberService {

	@Autowired
	MemberRepository repository;

	@Autowired
	LoyalitySegmentRepository loyalitySegmentRepository;

	public List<LoyalitySegment> getLoyalitySegment(String emailID) {
		Members member = repository.findByemailId(emailID);
		List<LoyalitySegment> loyalitySegment = loyalitySegmentRepository.findAll();
		
		List<LoyalitySegment> listOfLoyalitySegment = new ArrayList<LoyalitySegment>();

		System.out.println("");
		
		
		for (LoyalitySegment loyality : loyalitySegment) {
			LoyalitySegment loyalitySeg = new LoyalitySegment();
			if (loyality.getLoyalityId().equalsIgnoreCase(member.getLoyalityId())) {
				loyalitySeg.setSegmentDescription(loyality.getSegmentDescription());
				loyalitySeg.setSegmentName(loyality.getSegmentName());
				listOfLoyalitySegment.add(loyalitySeg);
			}

		}

		return listOfLoyalitySegment;
	}

}
