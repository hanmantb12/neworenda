package com.tibco.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
@Entity
@Table(name = "loyalty_segments")
public class LoyalitySegment {
	@Id
	private int id;
	@Column(name = "LOYALTY_ID")
	private String loyalityId;
	@Column(name = "SEGMENT_NAME")
	private String segmentName;
	@Column(name = "SEGMENT_DESCRIPTION")
	private String segmentDescription;
	

}
