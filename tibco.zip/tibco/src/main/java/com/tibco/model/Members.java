package com.tibco.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
@Entity
@Table(name = "members")
public class Members {
	@Id
	@Column(name = "LOYALTY_ID")
	private String loyalityId;
	@Column(name = "EMAIL_ID")
	private String emailId;
	@Column(name = "PHONE_NUMBER")
	private Integer phoneNumber;
	@Column(name = "FIRST_NAME")
	private String firstName;
	@Column(name = "LAST_NAME")
	private String lastName;
	

}
